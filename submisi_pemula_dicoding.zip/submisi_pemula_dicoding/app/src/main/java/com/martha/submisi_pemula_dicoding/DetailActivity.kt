package com.martha.submisi_pemula_dicoding

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import coil.load
import coil.transform.RoundedCornersTransformation
import com.martha.submisi_pemula_dicoding.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_DETAIL = "extra_detail"
    }

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val produk = intent.getParcelableExtra<Produk>(EXTRA_DETAIL)

        binding.tvName.text = produk?.nama
        binding.tvPrice.text = produk?.harga
        binding.tvOverview.text = produk?.deskripsi
        binding.imgPoster.load(produk?.foto) {
            crossfade(true)
            crossfade(1000)
            transformations(RoundedCornersTransformation(10f))
        }

        binding.icBack.setOnClickListener { finish() }
    }
}