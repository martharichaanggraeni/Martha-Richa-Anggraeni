package com.martha.submisi_pemula_dicoding

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import coil.load
import coil.transform.CircleCropTransformation
import com.martha.submisi_pemula_dicoding.databinding.ActivityProfilBinding

class ProfilActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfilBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfilBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.imgPhoto.load(R.drawable.martha) {
            crossfade(true)
            crossfade(2000)
            transformations(CircleCropTransformation())
        }

        binding.icBack.setOnClickListener { finish() }
    }
}