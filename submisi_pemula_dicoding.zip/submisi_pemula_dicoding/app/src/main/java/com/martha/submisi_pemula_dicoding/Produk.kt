package com.martha.submisi_pemula_dicoding


import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Produk(
    val nama: String,
    val harga: String,
    val deskripsi: String,
    val foto: String
) : Parcelable
