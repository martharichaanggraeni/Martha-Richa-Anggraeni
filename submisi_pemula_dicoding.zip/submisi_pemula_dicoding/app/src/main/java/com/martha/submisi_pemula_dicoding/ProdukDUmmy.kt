package com.martha.submisi_pemula_dicoding

import android.net.Uri

object ProdukDUmmy {

    fun getDataProduk(): List<Produk> {
        val listBegift = mutableListOf<Produk>()

        listBegift.add(
            Produk(
                "Tahu Gimbal",
                "Rp 50000",
                "Tahu gimbal merupakan masakan khas Semarang yang terbuat dari tahu goreng, sayuran, dan bakwan udang. Sajian ini ditambahkan juga dengan kuah kacang yang terbuat dari kacang goreng tumbuk kasar.",
                "${Uri.parse("android.resource://com.martha.submisi_pemula_dicoding/drawable/tahugimbal")}"
            )
        )
        listBegift.add(
            Produk(
                "Lumpia Semarang",
                "Rp 20, 000",
                "Isian dari makanan dengan nama lain lunpia ini adalah daging ayam, bawang putih, telur orak-arik, ebi, kecap, potongan sayuran, bahkan rebung.",
                "${Uri.parse("android.resource://com.martha.submisi_pemula_dicoding/drawable/lumpia")}"
            )
        )
        listBegift.add(
            Produk(
                "Bandeng Presto",
                "50, 000",
                "Wilayah Kota Semarang dikenal memiliki pesisir pantai sehingga banyak makanan dari Semarang yang memanfaatkan ikan sebagai makanan utama. Salah satunya bandeng presto.",
                "${Uri.parse("android.resource://com.martha.submisi_pemula_dicoding/drawable/bandengpresto")}"
            )
        )
        listBegift.add(
            Produk(
                "Wingko Babat",
                "Rp 75.000",
                "Wingko babat merupakan panganan khas ibukota Jawa Tengah yang punya rasa manis dan gurih dari parutan kelapa. Makanan tradisional ini terbuat dari tepung ketan, gula pasir, telur, dan margarin.",
                "${Uri.parse("android.resource://com.martha.submisi_pemula_dicoding/drawable/wingkobabat")}"
            )
        )
        listBegift.add(
            Produk(
                "Lontong Spekoek",
                "Rp 55.000",
                "Bagi yang belum tahu tentang spekoek, maka spekoek adalah nama beken dari kue tradisional bernama lapis legit. Kue dengan ciri khas warna cokelat dan kuning yang berlapis-lapis itu memiliki rasa legit sesuai namanya.",
                "${Uri.parse("android.resource://com.martha.submisi_pemula_dicoding/drawable/lontongspeokok")}"
            )
        )
        listBegift.add(
            Produk(
                "Roti Ganjel Rel",
                "Rp 15.000",
                "Salah satu roti khas Semarang yang kini mulai sulit ditemukan adalah roti ganjel rel karena mulai sedikit peminatnya. Bentuk dari panganan ini mirip dengan alat musik gambang dengan bentuk kotak warna cokelat bertabur wijen di sekelilingnya. ",
                "${Uri.parse("android.resource://com.martha.submisi_pemula_dicoding/drawable/rotiganjel")}"
            )
        )
        listBegift.add(
            Produk(
                "Pisang Plenet ",
                "Rp 38.000",
                "Mungkin pisang plenet tak seterkenal lumpia, Wingko, atau bandeng presto yang notabene sama-sama makanan khas Semarang. Hal inilah yang membuat pisang plenet hampir punah karena sulit ditemui.",
                "${Uri.parse("android.resource:/com.martha.submisi_pemula_dicoding/drawable/pisangplenet")}"
            )
        )
        listBegift.add(
            Produk(
                "Sego Koyor",
                "Rp 55.000",
                "Sego koyor merupakan hidangan nasi putih yang disajikan dalam piring dan diberi potongan koyor. Tak lupa, disiram juga dengan kuah koyor. Ada tambahan lalapan mentimun dan petai goreng.",
                "${Uri.parse("android.resource://com.martha.submisi_pemula_dicoding/drawable/segokoyor")}"
            )
        )
        listBegift.add(
            Produk(
                "Tahu Pong",
                "Rp 42.000 - 55.000(non shopee) / Rp 55.000 - 70.000(shopee)",
                "Beberapa waktu lalu, ada tahu bulat yang digoreng dadakan dengan harga 500-an dan sudah pasti kehalalannya. Namun jauh sebelum itu ternyata ada makanan khas Semarang bernama tahu pong dengan persamaannya adalah terbuat dari tahu dengan isian sama-sama kopong.",
                "${Uri.parse("android.resource://com.martha.submisi_pemula_dicoding/drawable/tahupotong")}"
            )
        )
        listBegift.add(
            Produk(
                "Mie Kopyok",
                "Rp 135.000",
                "Mie kopyok adalah makanan dengan bahan utama mie lalu ditambah dengan tetelan daging dengan tambahan lauk berupa tahu dan kerupuk gendar. Gendar merupakan kerupuk yang terbuat dari adonan nasi dengan rasa renyah nan gurih.",
                "${Uri.parse("android.resource://com.martha.submisi_pemula_dicoding/drawable/miekopyok")}"
            )
        )

        return listBegift
    }
}